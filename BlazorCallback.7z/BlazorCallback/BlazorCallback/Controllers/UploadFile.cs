﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace BlazorCallback.Controllers
{
    //[Produces("application/json")]
    public class UploadFile : Controller
    {
        Microsoft.AspNetCore.Hosting.IWebHostEnvironment _hostingEnvironment;

        public UploadFile(Microsoft.AspNetCore.Hosting.IWebHostEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;

        }

        [Route("api/[controller]/Load")]
        [HttpPost]
        public IActionResult Load([FromBody] dynamic fileNameObject)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var dynamicObject = JsonConvert.DeserializeObject<dynamic>(fileNameObject.ToString())!;
            var fileName = dynamicObject.file.ToString();

            char[] charArray = fileName.ToCharArray();
            Array.Reverse(charArray);
            var reversedFileName = new string(charArray);

            return new JsonResult($"Success for {reversedFileName}");

            //return CreatedAtAction("GetCustomer", new { id = customer.ID }, customer);
        }

        public async Task<IActionResult> Load2([FromBody] dynamic fileName)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            return Ok($"Success for {fileName}");

            //return CreatedAtAction("GetCustomer", new { id = customer.ID }, customer);
        }
    }
}
