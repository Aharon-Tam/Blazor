﻿using System.Collections.Generic;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace BlazorInlineDataGrid.Data
{
    public class CurveService
    {
        private List<CurveChart> curves = new List<CurveChart>()
        {
            new CurveChart() { Id = 1, Topic = "MO21A" },
            new CurveChart() { Id = 2, Topic = "MO21B" },
            new CurveChart() { Id = 3, Topic = "MO21C" },
            new CurveChart() { Id = 4, Topic = "MO21D" },
    };


        public async Task<List<CurveChart>> Curves()
        {
            return await Task.FromResult(curves);
        }
    }
}
