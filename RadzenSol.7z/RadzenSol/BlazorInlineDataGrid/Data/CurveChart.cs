﻿namespace BlazorInlineDataGrid.Data
{
    public class CurveChart
    {
        public int Id { get; set; }
        public string Topic { get; set; }
    }
}
