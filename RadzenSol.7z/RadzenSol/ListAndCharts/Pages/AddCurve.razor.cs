﻿namespace ListAndCharts.Pages
{
    public partial class AddCurveComponent
    {

    }
}
