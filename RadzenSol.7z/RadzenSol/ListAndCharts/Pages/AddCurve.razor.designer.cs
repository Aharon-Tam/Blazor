﻿using System;
using System.Collections.Generic;
using ListAndCharts.Models;
using ListAndCharts.Services;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;
using Radzen;

namespace ListAndCharts.Pages
{
    public partial class AddCurveComponent : ComponentBase
    {
        [Parameter(CaptureUnmatchedValues = true)]
        public IReadOnlyDictionary<string, dynamic> Attributes { get; set; }

        [Inject]
        protected IJSRuntime JSRuntime { get; set; }

        [Inject]
        protected NavigationManager UriHelper { get; set; }

        [Inject]
        protected DialogService DialogService { get; set; }

        [Inject]
        protected NotificationService NotificationService { get; set; }

        [Inject]
        protected CurvesService Northwind { get; set; }

        CurveChart _region;
        protected CurveChart region
        {
            get
            {
                return _region;
            }
            set
            {
                if(!object.Equals(_region, value))
                {
                    _region = value;
                    InvokeAsync(() => { StateHasChanged(); });
                }
            }
        }

        protected override async System.Threading.Tasks.Task OnInitializedAsync()
        {
            await Load();
        }
        protected async System.Threading.Tasks.Task Load()
        {
            region = new CurveChart();
        }

        protected async System.Threading.Tasks.Task Form0Submit(CurveChart args)
        {
            try
            {
                var northwindCreateRegionResult = await Northwind.Add(region);
                DialogService.Close(region);
            }
            catch (Exception northwindCreateRegionException)
            {
                    NotificationService.Notify(NotificationSeverity.Error, $"Error", $"Unable to create new Region!");
            }
        }

        protected async System.Threading.Tasks.Task Button2Click(MouseEventArgs args)
        {
            DialogService.Close(null);
        }
    }
}
