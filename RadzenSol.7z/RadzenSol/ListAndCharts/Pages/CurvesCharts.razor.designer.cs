﻿using System;
using System.Collections.Generic;
using ListAndCharts.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;
using Radzen;
using Radzen.Blazor;

namespace ListAndCharts.Pages
{
    public partial class CurvesComponent : ComponentBase
    {
        [Parameter(CaptureUnmatchedValues = true)]
        public IReadOnlyDictionary<string, dynamic> Attributes { get; set; }

        [Inject]
        protected IJSRuntime JSRuntime { get; set; }

        [Inject]
        protected NavigationManager UriHelper { get; set; }

        [Inject]
        protected DialogService DialogService { get; set; }

        [Inject]
        protected NotificationService NotificationService { get; set; }

        [Inject]
        protected Services.CurvesService Northwind { get; set; }

        protected RadzenGrid<CurveChart> grid0;

        IEnumerable<CurveChart> _getRegionsResult;
        protected IEnumerable<CurveChart> getRegionsResult
        {
            get
            {
                return _getRegionsResult;
            }
            set
            {
                if(!object.Equals(_getRegionsResult, value))
                {
                    _getRegionsResult = value;
                    InvokeAsync(() => { StateHasChanged(); });
                }
            }
        }

        protected override async System.Threading.Tasks.Task OnInitializedAsync()
        {
            await Load();
        }
        protected async System.Threading.Tasks.Task Load()
        {
            var northwindGetRegionsResult = await Northwind.GetRegions();
            getRegionsResult = northwindGetRegionsResult;
        }

        protected async System.Threading.Tasks.Task Button0Click(MouseEventArgs args)
        {
            var result = await DialogService.OpenAsync<AddCurve>("Add Region", null);
              grid0.Reload();

              await InvokeAsync(() => { StateHasChanged(); });
        }

        protected async System.Threading.Tasks.Task Grid0RowSelect(CurveChart args)
        {
            var result = await DialogService.OpenAsync<EditRegion>("Edit CurveChart", new Dictionary<string, object>() { {"RegionID", args.RegionID} });
              await InvokeAsync(() => { StateHasChanged(); });
        }

        protected async System.Threading.Tasks.Task GridDeleteButtonClick(MouseEventArgs args, CurveChart data)
        {
            try
            {
                var northwindDeleteRegionResult = await Services.CurvesService.DeleteCurveChart(data.CurveName);
                if (northwindDeleteRegionResult != null) {
                    grid0.Reload();
}
            }
            catch (Exception exception)
            {
                    NotificationService.Notify(NotificationSeverity.Error, $"Error", $"Unable to delete Curve");
            }
        }
    }
}
