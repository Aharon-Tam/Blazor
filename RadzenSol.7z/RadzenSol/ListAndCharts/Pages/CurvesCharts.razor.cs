﻿namespace ListAndCharts.Pages
{
    public partial class CurvesComponent
    {

    }
}
