using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ListAndCharts.Models
{
  public partial class CurveChart
  {
    [Key]
    public string CurveName
    {
      get;
      set;
    }


    public ICollection<string> CurveNames { get; set; }
    public string CurveDescription
    {
      get;
      set;
    }
  }
}
