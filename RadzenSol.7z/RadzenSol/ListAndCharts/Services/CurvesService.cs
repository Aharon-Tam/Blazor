using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ListAndCharts.Models;
using Microsoft.AspNetCore.Components;

namespace ListAndCharts.Services
{
    public partial class CurvesService
    {
        private readonly NavigationManager _navigationManager;
        private ICollection<CurveChart> Curves { get; }
        public CurvesService(NavigationManager navigationManager)
        {
            _navigationManager = navigationManager;

            var list = new List<Models.CurveChart>() { new CurveChart() { CurveName = "MO21" }, new CurveChart() { CurveName = "NYIRD" } };
            Curves = list;
        }

        partial void OnRegionsRead(ref IQueryable<Models.CurveChart> items);

        public async Task<IQueryable<CurveChart>> GetRegions()
        {
            var items = Curves.AsQueryable();

            OnRegionsRead(ref items);

            return await Task.FromResult(items);
        }

        partial void OnRegionCreated(CurveChart item);

        public async Task<Models.CurveChart> Add(CurveChart curveChart)
        {
            OnRegionCreated(curveChart);

            Curves.Add(curveChart);

            return curveChart;
        }

        public async Task<CurveChart> Delete(CurveChart curveChart)
        {
            OnRegionCreated(curveChart);

            Curves.Remove(curveChart);

            return curveChart;
        }

        partial void OnRegionDeleted(CurveChart item);

        public static async Task<CurveChart> DeleteCurveChart(string curveName)
        {
            var item = Curves.FirstOrDefault(cv => cv.CurveName == curveName);

            if (item == null)
            {
                throw new Exception("Item no longer available");
            }

            OnRegionDeleted(item);

            Curves.Remove(item);

            return item;
        }

        partial void OnRegionGet(CurveChart item);

        public async Task<CurveChart> GetCurveChart(string curveName)
        {
            var items = Curves.Where(cv => cv.CurveName == curveName);

            var item = items.FirstOrDefault();

            OnRegionGet(item);

            return await Task.FromResult(item);
        }

        public async Task<CurveChart> CancelCurveChanges(CurveChart item)
        {
            return item;
        }

        partial void OnCurveChartUpdated(CurveChart item);

        public async Task<CurveChart> UpdateCurveChart(CurveChart curveChart)
        {
            OnCurveChartUpdated(curveChart);

            if (curveChart == null)
            {
                throw new Exception("Item no longer available");
            }

            return curveChart;
        }
    }
}

