﻿https://blazor.radzen.com/line-chart

https://blazor.radzen.com/datagrid-inline-edit
