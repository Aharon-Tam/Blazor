using System.ComponentModel.DataAnnotations;

namespace BlazorDataGrid.Models
{
    public partial class OrderDetail
    {
        [Key] public int OrderId { get; set; }
        public string Product { get; set; }
    }
}
